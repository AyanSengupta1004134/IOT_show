package com.mouser.iotshow;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class GreetingActivity extends Activity {

    TextView grt;
    ImageView imageview;
    private static final int CAMERA_REQUEST = 1888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_greeting);

        imageview = (ImageView) findViewById(R.id.imageview);
        grt = (TextView) findViewById(R.id.grt);
        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("name");
//        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        //startActivityForResult(cameraIntent, CAMERA_REQUEST);


        grt.setText("Thank You  Have a nice Day");
        //imageview.setImageBitmap(photo);

    }


}
