package com.mouser.iotshow;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.independentsoft.share.FieldValue;
import com.independentsoft.share.ListItem;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class UserInfo extends Activity {

    EditText name,cname,designation,email,phn;
    Button pic,submit;
    String value,sendname;
    String namejson,cnamejson,designationjson,emailjson,phonejson,titlejson;
    String n,c,d,e,p,t;
    private static final int CAMERA_REQUEST = 1;
    private ImageView imageView;
    Bitmap photo;
    byte[] byteArray;
    FileInputStream fileStream = null;

    File file;
    Uri fileUri;
    final int RC_TAKE_PHOTO = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        name = (EditText) findViewById(R.id.name);
        cname = (EditText) findViewById(R.id.cname);
        designation = (EditText) findViewById(R.id.designation);
        email = (EditText) findViewById(R.id.email);
        phn = (EditText) findViewById(R.id.phn);

        name.setEnabled(false);
        cname.setEnabled(false);
        designation.setEnabled(false);
        email.setEnabled(false);
        phn.setEnabled(false);

        pic = (Button) findViewById(R.id.pic);
        submit = (Button) findViewById(R.id.submit);

//        name.getBackground().setAlpha(30);
//        cname.getBackground().setAlpha(30);
//        designation.getBackground().setAlpha(30);
//        email.getBackground().setAlpha(30);
//        phn.getBackground().setAlpha(30);

        pic.getBackground().setAlpha(30);
        submit.getBackground().setAlpha(30);

        this.imageView = (ImageView)this.findViewById(R.id.imageview);


        Bundle bundle = getIntent().getExtras();
        if(UserCheck.user == 1)
        {
            value = bundle.getString("phone");
        }

        else if(UserCheck.user ==2)
        {
            value = bundle.getString("email");
        }

        StringBuffer sb = new StringBuffer();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(getAssets().open(
                    "Contact.json")));
            String temp;
            while ((temp = br.readLine()) != null)
                sb.append(temp);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                br.close(); // stop reading
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String myjsonstring = sb.toString();


        try {

            JSONObject jsonObjMain = new JSONObject(myjsonstring);


            JSONArray jsonArray = jsonObjMain.getJSONArray("Contacts");


            for (int i = 0; i<jsonArray.length(); i++) {


                JSONObject jsonObj = jsonArray.getJSONObject(i);


                titlejson = jsonObj.getString("Title");
                namejson = jsonObj.getString("Name");
                cnamejson = jsonObj.getString("CName");
                designationjson = jsonObj.getString("Designation");
                emailjson = jsonObj.getString("Email");
                phonejson = jsonObj.getString("Phone");

                if(value.equals(phonejson) || value.equals(emailjson))
                {
                    name.setText(namejson);
                    sendname = namejson;
                    cname.setText(cnamejson);
                    designation.setText(designationjson);
                    email.setText(emailjson);
                    phn.setText(phonejson);
                    n = namejson;
                    c=cnamejson;
                    d=designationjson;
                    e=emailjson;
                    p=phonejson;
                    t=titlejson;

                }



            }

        } catch (JSONException e) {

            e.printStackTrace();
        }


        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);

                startActivityForResult(cameraIntent, CAMERA_REQUEST);

//                file = new File(getExternalCacheDir(),
//                        String.valueOf(System.currentTimeMillis()) + ".jpg");
//                fileUri = Uri.fromFile(file);
//                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
//                startActivityForResult(cameraIntent, RC_TAKE_PHOTO);
//
//                Toast.makeText(UserInfo.this,fileUri+"",Toast.LENGTH_SHORT).show();
                imageView.setVisibility(View.VISIBLE);
                submit.setVisibility(View.VISIBLE);
                pic.setVisibility(View.INVISIBLE);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                new MyAsyncTask().execute();

                AlertDialog.Builder builder = new AlertDialog.Builder(UserInfo.this);
                builder.setMessage("Thank You Have a nice Day");
                builder.setCancelable(false);
                builder.setNeutralButton("                  Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Intent intent = new Intent(UserInfo.this, MainActivity.class);
                        startActivity(intent);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            photo = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(photo);


        }
    }


    private class MyAsyncTask extends AsyncTask<String, Integer, String> {


        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            String s=postData();
            return s;
        }

        protected void onPostExecute(String result){

            //text.setText("true");
        }
        protected void onProgressUpdate(Integer... progress){

        }

        public String postData() {

            String returnValue = "";
//            String ListId = "459437f8-89d3-4138-ad0d-b53955494e58";
            String ListId = "519df170-cfa9-4ddb-81bf-d91ef1849a7c";
            String List= "459437f8-89d3-4138-ad0d-b53955494e58";
            String idp="";


            try {
                Service service = new Service("https://sp2013.mouser.lan/sites/Demonstration/", "ayan.sengupta","Mouser123");

                java.util.List<ListItem> arrayList = new ArrayList<>();
                arrayList=service.getListItems(List);
                for (int i=0;i<arrayList.size();i++)
                {
                    idp=arrayList.get(i).getTitle();
                }

//                System.out.println("Id: " + createdItem.getId());
                ListItem item = new ListItem("Name");


                ListItem createdItem = service.createListItem(ListId, item);

                int id = createdItem.getId();

                FileInputStream fileStream = null;

//                String name= title.getText().toString();
//                String empname1 = empname.getText().toString();
//                String empdept1 = empdept.getText().toString();

                FieldValue fieldValue1 = new FieldValue("Title", t);
                FieldValue fieldValue2 = new FieldValue("Name", n);
                FieldValue fieldValue3 = new FieldValue("CompanyName", c);
                FieldValue fieldValue4 = new FieldValue("Designation", d);
                FieldValue fieldValue5 = new FieldValue("Email", e);
                FieldValue fieldValue6 = new FieldValue("PhoneNumber", p);

//
                /*This is image code*/
//

//                Bitmap bm = BitmapFactory.decodeFile("/storage/ext_sd/DCIM/100MEDIA/images.jpg");
//                ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
//                byte[] b = baos.toByteArray();
//                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
//                FieldValue fieldValue4 = new FieldValue("Image", encodedImage);


                /*end*/
                service.setFieldValue(ListId, id, fieldValue1);
                service.setFieldValue(ListId, id, fieldValue2);
                service.setFieldValue(ListId, id, fieldValue3);
                service.setFieldValue(ListId, id, fieldValue4);
                service.setFieldValue(ListId, id, fieldValue5);
                service.setFieldValue(ListId, id, fieldValue6);
                //service.setFieldValue("459437f8-89d3-4138-ad0d-b53955494e58", id, fieldValue4);

                // list id
                // row id


                fileStream = new FileInputStream("/storage/ext_sd/DCIM/100MEDIA/IMAG"+idp+".jpg");
                //Attachment attachment = new Attachment();
                service.createListItemAttachment(ListId, id, n+".jpg",fileStream);
                int in= Integer.parseInt(idp);
                in = in+1;
                String ina = Integer.toString(in);

                ListItem item1 = new ListItem("Name");


                ListItem createdItem1 = service.createListItem(List, item1);
                int id1 = createdItem1.getId();

                FieldValue fieldValue = new FieldValue("Title", "0"+ina);

                service.setFieldValue(List,id1,fieldValue);



//                text.setText("true");
                //text.setText(id);

            }
            catch (ServiceException ex)
            {

                Log.w("ServiceException", ":" + ex.getMessage());

                Log.w("ServiceException", ":" + ex.getRequestBody());
            }
            catch (Exception ex)
            {
                Log.w("Exception", ex.getMessage());
            }

            return returnValue;
        }
    }



    @Override
    public void onBackPressed() {
        // finish() is called in super: we only override this method to be able to override the transition
        super.onBackPressed();

        Intent intent = new Intent(UserInfo.this,MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_and_changebounds, R.anim.slide_and_changebounds_sequential);
    }
}



