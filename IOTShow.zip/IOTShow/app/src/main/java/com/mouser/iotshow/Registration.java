package com.mouser.iotshow;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends Activity {

    EditText name,cname,designation,email,phn;
    Button submit;

    String names,cnames,designations,emails,phns;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name = (EditText) findViewById(R.id.name);
        cname = (EditText) findViewById(R.id.cname);
        designation = (EditText) findViewById(R.id.designation);
        email = (EditText) findViewById(R.id.email);
        phn = (EditText) findViewById(R.id.phn);

        submit = (Button) findViewById(R.id.submit);
        submit.getBackground().setAlpha(30);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                names = name.getText().toString();
                cnames = cname.getText().toString();
                designations = designation.getText().toString();
                emails = email.getText().toString();
                phns = phn.getText().toString();

                Intent intent = new Intent(Registration.this, MainActivity.class);
                //intent.putExtra("name", names);
                Toast.makeText(Registration.this,"Thank You for Registering",Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });
    }



    @Override
    public void onBackPressed() {
        // finish() is called in super: we only override this method to be able to override the transition
        super.onBackPressed();
        Registration.this.finish();
        Intent intent = new Intent(Registration.this,MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_and_changebounds, R.anim.slide_and_changebounds_sequential);
    }

}
