package com.mouser.iotshow;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class Feedback extends Activity {


    String value;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        btn = (Button) findViewById(R.id.btn);


        Bundle bundle = getIntent().getExtras();
        if(UserCheck.user == 1)
        {
            value = bundle.getString("phone");
        }

        else if(UserCheck.user ==2)
        {
            value = bundle.getString("email");
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Feedback.this);
                builder.setMessage(R.string.greet);
                builder.setCancelable(false);
                builder.setNeutralButton("             Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Intent intent = new Intent(Feedback.this, MainActivity.class);
                        startActivity(intent);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });


    }


    @Override
    public void onBackPressed() {
        // finish() is called in super: we only override this method to be able to override the transition
        super.onBackPressed();
        Feedback.this.finish();
        Intent intent = new Intent(Feedback.this,MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_and_changebounds, R.anim.slide_and_changebounds_sequential);
    }

}
